#!/usr/bin/env bash

rm -f *.pem
rm -f *.key
rm -f *.crt
rm -f *.csr