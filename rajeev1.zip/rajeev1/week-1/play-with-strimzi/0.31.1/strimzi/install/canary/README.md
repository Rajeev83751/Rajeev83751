# Strimzi Canary

Strimzi canary is a tool which acts as an indicator of whether Kafka clusters are operating correctly.
This is achieved by creating a canary topic and periodically producing and consuming events on the topic and getting metrics out of these exchanges.

For more information and installation guide, see [https://github.com/strimzi/strimzi-canary](https://github.com/strimzi/strimzi-canary).