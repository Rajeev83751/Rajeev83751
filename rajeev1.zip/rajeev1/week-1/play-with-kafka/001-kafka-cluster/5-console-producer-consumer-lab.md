


console producer
```bash
kafka-console-producer --topic test --bootstrap-server localhost:9092
```

console consumer
```bash
kafka-console-consumer --topic test --bootstrap-server localhost:9092 --from-beginning
```