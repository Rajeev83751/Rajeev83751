


edit properties file to set plugin path "connect-distributed.properties"

plugin.path=


start connet worker in distributed mode

```bash
$ ./bin/connect-distributed.sh etc/kafka/connect-distributed.properties
```

